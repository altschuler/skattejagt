namespace Skattejagt
{
    public enum Tile
    {
	Entry,
	Wall,
	Floor,
	Treasure,
	Invalid
    } 
}